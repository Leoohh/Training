class Aula7b {

	static BinaryImage aleatoria (int w, int h){
		BinaryImage img=new BinaryImage(w,h);
		for (int i=0; i<w; i++){
			for(int j=0; j<h; j++){
				//	int a=(int)(Math.random()*2);
				if (Math.random()<0.5)
					img.setWhite(i,j);
			}
		}
		return img;
	}

	static void paintSquare (BinaryImage img,int x, int y, int side){
		for (int i=x; i<(x+side); i++){
			for (int j=y; j<(y+side); j++){
				img.setWhite(i,j);
			}
		}
		return;
	}

	static void contorno (BinaryImage img, int x, int y, int side){
		//	paintSquare(img,x,y,side);
		for (int i=x; i<=(x+side); i++){
			img.setBlack(i,y);
			img.setBlack(i,y+side);
		}
		for (int j=y; j<=(y+side); j++){
			img.setBlack (x,j);
			img.setBlack (x+side,j);
		}
		return;
	}
	static void testC (int x, int y, int side){
		BinaryImage img= aleatoria(200,100);
		contorno(img, x,y,side);
		return;
	}

	static void testB (int x, int y, int side){
		BinaryImage img= aleatoria(400,400);
		paintSquare(img, x,y,side);
		return;
	}

	static BinaryImage xadrez (int n){
		BinaryImage board= new BinaryImage (8*n,8*n);
		for (int i=0; i<8; i++){
			for (int j=0; j<8; j++){
				if ((i+j)%2!=1)
					paintSquare (board, i*n,j*n,n-1);
			}
		}
		contorno(board,0,0,8*n-1);
		return board;
	}

	//Listraas
	static BinaryImage listras (int n){
		BinaryImage board= new BinaryImage (8*n,8*n);
		for (int i=0; i<board.getWidth(); i++){
			for (int j=0; j<board.getHeight(); j++){
				if (i/n%2==1)
					board.setWhite(i,j);
			}
		}
		return board;
	}

	//E
	static void inverte (BinaryImage img){
		for (int i=0; i<img.getWidth(); i++){
			for (int j=0; j<img.getHeight(); j++){
				if (img.isBlack(i,j))
					img.setWhite(i,j);
				else
					img.setBlack (i,j);
			}
		}
		return;
	}
	static void testeE(int n){
		BinaryImage img= xadrez (n);
		inverte(img);
		return;
	}
	//E2
	static BinaryImage inverte2 (BinaryImage img){
		BinaryImage a= new BinaryImage(img.getWidth(),img.getHeight());
		for (int i=0; i<img.getWidth(); i++){
			for (int j=0; j<img.getHeight(); j++){
				if (img.isBlack(i,j))
					a.setWhite(i,j);
				else
					a.setBlack (i,j);
			}
		}
		return a;
	}
	static BinaryImage testeE2(int n){
		BinaryImage img= xadrez (n);
		return inverte2(img);
	}

	//F
	static BinaryImage scale(BinaryImage image, int factor){

		BinaryImage b = new BinaryImage ( factor*image.getHeight(),
				factor*image.getWidth() );

		for ( int i = 0; i < b.getHeight(); i++) {
			for ( int j = 0; j < b.getWidth(); j++) {
				if ( !image.isBlack( i/factor, j/factor) )
					b.setWhite(i, j);
			}
		}
		return b;
	}


	static BinaryImage testeF(int n, int factor){
		BinaryImage img= xadrez (n);
		return scale(img, factor);
	}


	//G 
		static BinaryImage merge1 (BinaryImage small, BinaryImage big){
		BinaryImage img= new BinaryImage(Math.max(big.getWidth(),small.getWidth()),Math.max(big.getHeight(),small.getHeight()));
		for (int i=0; i<img.getWidth();i++){
			for (int j=0; j<img.getHeight();j++){
				if ( i < small.getWidth() && j<small.getHeight() &&!small.isBlack(i,j))
					img.setWhite(i,j);
				else if ( i < small.getWidth() && j<small.getHeight() && small.isBlack(i,j))
					img.setBlack(i,j);
				else if ((i>small.getWidth()||j>small.getHeight())&&!big.isBlack(i,j))
					img.setWhite(i,j);
				else if ((i>small.getWidth()||j>small.getHeight())&&big.isBlack(i,j))
					img.setBlack(i,j);
			}
			
		}

		return img;
	}
	static BinaryImage testeG(){
		BinaryImage img1= xadrez (15);
		BinaryImage img2= xadrez (30);
		return merge(img1,img2);
	}	
			

	static void circulo (BinaryImage img, int cX, int cY, int raio){
		for (int i=0; i<img.getWidth();i++){
			for(int j=0; j<img.getHeight();j++){
				if(((i-cX)*(i-cX)+(j-cY)*(j-cY))<=raio*raio){
					if (Math.random()<0.5)
						img.setWhite(i,j);
				}
			}
		}
		return;
	}
	
	static void testeH (int cX,int cY, int raio){
		BinaryImage img= new BinaryImage(100,200);
		circulo(img,cX,cY,raio);
		return;
	}




}