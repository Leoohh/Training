class Aula7 {
	
	static Color randomColor(){
		int r=(int)(Math.random()*255);
		int g=(int)(Math.random()*255);
		int b=(int)(Math.random()*255);
		Color c = new Color(r,g,b);
		return c;
	}
	
	static Color[] randomColorArray (int n){
		Color[] c= new Color[n];
		for(int i=0; i<n; i++)
			c[i]=randomColor();
		return c;
	}
	
	static Color inverted (Color c){
		Color c1=new Color (255-c.getR(),255-c.getG(), 255-c.getB());
		return c1;
	}
	
	static Color teste1 (){
		Color c= new Color (2,5,1);
		return inverted(c);
	}
	
	static Color changeBrigthness (Color color, int factor){
		Color a= new Color(limit(color.getR()+factor), limit(color.getG()+factor), limit(color.getB()+factor));
	return a;
	}
	
	static int limit (int n){
		if (n<0) return 0;
		if (n>255) return 255;
		return n;
	}
	
	static Color testeD (int factor){
		Color c= new Color(0,0,0);
		return changeBrigthness(c, factor);
	}
	

}
