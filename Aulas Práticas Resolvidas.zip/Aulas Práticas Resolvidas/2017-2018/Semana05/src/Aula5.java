class Aula5 {

	//Pr�vio

	//A
	static char[] charVetor(char c, int n){
		char[] vetor=new char[n];
		for (int i=0; i<vetor.length; i++)
			vetor[i]=c;
		return vetor;
	}

	//B
	static void fill (char c, char[]v){
		for (int i=0; i<v.length; i++)
			v[i]=c;
	}

	static void testeB (){
		char c='a';
		char[] v={'b','c','r','d'};
		return;
	}
	//C
	static void replace (char a, char b, char[]v){
		for (int i=0;i<v.length; i++){
			if (v[i]==a)
				v[i]=b;
		}
	}

	static void testeC (){
		char a='b';
		char b='a';
		char[] v={'b','c','b','d'};//@string
		replace(a,b,v);
		return;
	}

	//Exerc�cios

	//A
	static char[] sequencia(char a, int n){
		char[]v=new char[n];
		for(int i=0; i<n; i++)
			v[i]=(char)(a+i);
		return v;
	}

	//B1	
	static void subst1 (char a, char b, char[]v){
		int i=0;
		while (i<v.length){
			if (v[i]==a){
				v[i]=b;
				return;
			}
			i++;
		}
	}

	static void testeB1 (char a, char b){
		char[]v={'r','t','y','t','u'};
		subst1(a,b,v);
	}


	//B2
	static void subst2 (char a, char b, char[]v){
		int i=v.length-1;
		while (i>=0){
			if (v[i]==a){
				v[i]=b;
				return;
			}
			i--;
		}
	}

	static void testeB2 (char a, char b){
		char[]v={'r','t','y','t','u'};
		subst2(a,b,v);
	}

	//B3
	static void esquerda (char[]v){
		char a=v[0];
		for (int i=1; i<v.length; i++)
			v[i-1]=v[i];
		v[v.length-1]=a;
	}

	static void testeB3 (){
		char[]v={'a','b','c','d'};
		esquerda(v);
	}

	//B4
	static void direita (char[]v){
		char a=v[v.length-1];
		for (int i=1; i<v.length; i++)
			v[v.length-i]=v[v.length-i-1];
		v[0]=a;
	}

	static void testeB4 (){
		char[]v={'a','b','c','d'};
		direita(v);
	}

	//B5
	static void troca (int n, int m, char v[]){
		char a=v[n];
		v[n]=v[m];
		v[m]=a;
	}

	static void testeB4 (int n, int m){
		char[]v={'a','b','c','d'};
		troca(n,m,v);
	}

	//B6
	static void inverter(char v[]){
		for (int i=0; i<v.length/2; i++){
			char aux= v[i];
			v[i]= v[v.length-i-1];
			v[v.length-i-1]=aux;
		}
	}

	static void testeB6 (){
		char[]v={'a','b','c','d', 'e'};
		inverter(v);
	}


	//C - TERMINAR
	static int aleatorio(int n){
		return (int)(Math.random()*n+1);
	}

	static char[] Baralhar (char[] v){
		for(int i=v.length-1;i>1; i--){
			int b= aleatorio(i)-1;
			troca (i, b, v);
		}
		return v;
	}

	static char[] TesteC (){
		char[]v={'a','b','c','d', 'e','f', 'g'};
		return Baralhar(v);
	}


	//D - Bubble Sort

	static void BubbleSort (char []v){
		boolean swap=true;
		while (swap==true){
			swap=false;
			for (int i=0; i<v.length-1; i++){
				if (v[i]>v[i+1]){
					troca(i,i+1,v);
					swap=true;
				}
			}
		}
	}
	static void testeD (){
		char[]v={'b','d','a','e','c'};
		BubbleSort(v);
	}


	//Bubble Sort 2
	static char[] sort ( char[] v ) {
		int i = 0;
		while ( i < v.length - 1 ) {
			int m = v[i];
			int j = i + 1;
			while ( j < v.length ) {
				if ( v[j] < m ) {
					troca ( i, j , v);
					m = v[i];
				}
				j = j + 1;
			}
			i = i + 1;
		}
		return v;
	} 

	static char[] testeD1 (){
		char[]v={'b','d','a','e','c'};
		return sort(v);
	}

	//Extras

	//A
	static char[] acrescentar (char a, char[]v){
		char[]v1=new char[v.length+1];
		v1[v1.length-1]=a;
		for (int i=0; i<v.length; i++)
			v1[i]=v[i];
		return v1;
	}

	static char[] Testea (char a){
		char[]v={'a','b','c','d', 'e','f', 'g'};
		return acrescentar(a, v);
	}

	//A1
	static char[] acrescentar1 (char a, char[]v){
		char[]v1=new char[v.length+1];
		v1[0]=a;
		for (int i=1; i<v1.length; i++)
			v1[v1.length-i]=v[v1.length-i-1];
		return v1;
	}

	static char[] Testea1 (char a){
		char[]v={'a','b','c','d', 'e','f', 'g'};
		return acrescentar1(a, v);
	}

	//B

	static char[] replace(char c, char[]v){
		int i=(int)(Math.random()*v.length);
		v[i]=c;
		return v;
	}
	
	static char[] TesteB (char a){
		char[]v={'a','b','c','d', 'e','f', 'g'};
		return replace(a, v);
	}

	//C
	
	static void trocaMetades(char[]v){
		if (v.length%2==0){
			for (int i=0; i<v.length/2; i++)
				troca (i, v.length/2+i,v);
		}
		else{
		for (int i=0; i<v.length/2; i++)
			troca (i,v.length/2+1+i, v);
		}
	}
	
	
	static void TesteC1 (){
		char[]v={'a','b','c','d','e'};
		trocaMetades(v);
	}
	
	
	//Mini teste 4
	
	static void p(double[] v, int i, double x) {
	    v[i] = x;
	}
	 
	 static void TesteMT (){
		 double[] u = {2.718, 3.14159};
		    double w = 1.41421;
		    p(u, 1, w);

		}
}