class teste {
	
	// OBS: N�o precisa usar c�digos para testar, basta criar o objeto,
	//e no PandionJ dar duplo clique no objeto e aparece as op��es dispon�veis.
	
	static void teste1 (){
		Calculator v= new Calculator();
		Calculator v1= new Calculator();
		v.clean();
		v.plus(3);
		v.subtra��o(1);
		v.multiplicar(1);
		v.potencia(0);
		v.divisao(2);
		v.resto(5);
	}
	
	static void teste2(){
		Rectangle r1=new Rectangle(200,210);
		Rectangle r2=new Rectangle(100);
		int a=r1.area();
		int b=r1.perimetro();
		boolean maior= r2.�Maior(r1);
		boolean m2= maior(r1,r2);
		Rectangle m3= maior2(r1,r2);
		BinaryImage img= new BinaryImage(r1);
		//img.invert();
		Point p=new Point(10,15);
		img.fillRectangleContorn(p,r2);
	}
	
	static void teste3(){
		Point p= new Point(10,5);
		Rectangle r1=new Rectangle(20,10);
		BinaryImage img= new BinaryImage(r1);
		img.isWhite(p);
		img.paint(p,true);
		img.getCount(true);
		img.getPoints(false);
	}
	
	static void teste4(){
		Rational r=new Rational(1,3);
		Rational r1=new Rational(1,2);
		boolean b=r.�Maiorque(r1);
		double a=r.decimal();
		Rational r3=r.sum(r1);
		Rational r4=r3.multiplica��o(r1);
		Rational r2= r3.multiplica��oEsc(3);
	}
	
	static void teste5(){
		Rectangle r=new Rectangle (40,90);
		BinaryImage img= new BinaryImage (60,120);
		for (int i=30; i<45; i++){
			for (int j=40; j<100; j++)
				img.setWhite(i,j);
		}
		img.changeSize(r);
	}
	
		
	static boolean maior (Rectangle r1, Rectangle r2){
    	return r1.area()>r2.area();
    }
	
	static Rectangle maior2 (Rectangle r1, Rectangle r2){
    	if(r1.area()>=r2.area())
    		return r1;
    	else return r2;
    }

}