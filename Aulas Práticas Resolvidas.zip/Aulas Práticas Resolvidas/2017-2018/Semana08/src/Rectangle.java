class Rectangle {
	
    final int width;
    final int height;

    Rectangle(int width, int height) {
          this.width = width;
          this.height = height;
    }
    
    Rectangle (int side){
    	this(side,side);
    }
    
    int area(){
    	return width*height;

    }
    
    int perimetro(){
    	return 2*width+2*height;
    }
    
    double diagonal(){
    	return Math.sqrt(width*width+height*height);
    }
    
    boolean �Quadrado(){
    return width==height;
    }
    
    Rectangle scale (int factor){
    	if (factor==1)
    		return this;
    	return new Rectangle(factor*width,factor*height);
    }
    
    Rectangle sum(int width, int height){
    	return new Rectangle(this.width+width,this.height+height);
    }
    
    boolean �Maior (Rectangle r){
    	return (area()>r.area());
    }
   
    
    
    



}