class Calculator {
	
	int value;
	
	void plus(int n){
		value+=n;
	}
	
//	Calculator(){
//		value=0;
//	}
	
//	Calculator(int value){
//		this.value=value;
//	}
	
	void clean(){
		value=0;
	}
	
	void subtra��o(int n){
		value-=n;
	}
	
	void multiplicar (int n){
		int aux=0;
		for (int i=1; i<n+1; i++)
			aux+=value;
		value=aux;
	}
	
	void potencia(int n){
		int aux=value;
		if(n==0)
			value=1;
		for (int i=2; i<n+1; i++)
			multiplicar(aux);
	}	
	
	void divisao (int n){
		int resto=value;
		int quociente = 0;
		while (resto>=n){
			resto=resto-n;
			quociente++;
		}
		value=quociente;
	}
	
	void resto (int n){
		int resto=value;
		while (resto>=n){
			resto=resto-n;
		}
		value=resto;
	}
		

}