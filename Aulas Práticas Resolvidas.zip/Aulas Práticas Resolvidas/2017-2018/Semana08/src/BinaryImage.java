/**
 * Represents binary images.
 * Image data is represented as a matrix:
 * - the number of lines corresponds to the image height (data.length)
 * - the length of the lines corresponds to the image width (data[*].length)
 * - false values are mapped to black
 * - true values are mapped to white
 */
class BinaryImage {

	private boolean[][] data; // @binaryimage

	/**
	 * Creates a black binary image with the given dimension in pixels.
	 */
	BinaryImage(int width, int height) {
		data = new boolean[height][width];
	}
	//Novo
	//1
	BinaryImage (Rectangle r){
		this(r.width,r.height);
	}
	//2
	Rectangle getSize(){
		Rectangle v=new Rectangle(getWidth(),getHeight());
		return v;
	}
//3
	boolean isWhite (Point p){
		return !isBlack(p.x,p.y);
	}
//4
	void paint (Point p, boolean white){
		if(white==true)
			setWhite(p.x,p.y);
		setBlack(p.x,p.y);
	}
//5
	int getCount (boolean white){
		int a=0;
		for (int i=0; i<this.getWidth(); i++){
			for (int j=0; j<this.getHeight(); j++){
				if (white==true){
					if(!this.isBlack(i,j))
						a++;
				}
				else if(this.isBlack(i,j))
					a++;
			}
		}
		return a;
	}
	//6
	Point[] getPoints (boolean white){
		Point[]p=new Point[this.getCount(white)];
		int a=0;
		for (int i=0; i<this.getWidth(); i++){
			for (int j=0; j<this.getHeight(); j++){
				if (white==true){
					if(!this.isBlack(i,j)){
						p[a]=new Point(i,j);
						a++;
					}
				}
				else
					if(this.isBlack(i,j)){
						p[a]=new Point(i,j);
						a++;
					}
			}
		}
		return p;
	}
	//7
	void invert (){
		for (int i=0; i<getWidth(); i++){
			for (int j=0; j<getHeight(); j++){
				if(isBlack(i,j))
					setWhite(i,j);
				else setBlack(i,j);
			}
		}
	}
	
	//8
	void fillRectangle(Point p, Rectangle r){
		for (int i=p.x; i<p.x+r.width; i++){
			for (int j=p.y; j<p.y+r.height; j++){
				setWhite(i,j);
			}
		}
	}
	void fillRectangleContorn(Point p, Rectangle r){
		for (int i=p.x; i<p.x+r.width; i++){
			for (int j=p.y; j<p.y+r.height; j++){
				setWhite(i,p.y);
				setWhite(i,p.y+r.height);
				setWhite(p.x,j);
				setWhite(p.x+r.width,j);
			}
		}
	}
	
	void changeSize(Rectangle r){
		boolean[][] img= new boolean[r.height][r.width];
		for(int i=0; i<r.width; i++){
			for(int j=0; j<r.height; j++){
				if(validPosition(i,j)){
					if(isBlack(i,j))
						img[j][i] = false;
					else img[j][i] = true;
				}
				else img[j][i] = false;
			}
		}
		data=img;
	}
		
		
				


	/**
	 * Image width in pixels.
	 */
	int getWidth() {
		return data[0].length;
	}

	/**
	 * Image height in pixels.
	 */
	int getHeight() {
		return data.length;
	}

	/**
	 * Is pixel at (x, y) black?
	 */
	boolean isBlack(int x, int y) {
		validatePosition(x, y);
		return !data[y][x];
	}

	/**
	 * Sets the pixel at (x, y) to white.
	 */
	void setWhite(int x, int y) {
		validatePosition(x, y);
		data[y][x] = true;
	}

	/**
	 * Sets the pixel at (x, y) to black.
	 */
	void setBlack(int x, int y) {
		validatePosition(x, y);
		data[y][x] = false;
	}

	/**
	 * Is (x, y) a valid pixel position in this image?
	 */
	boolean validPosition(int x, int y) {
		return 
				x >= 0 && x < getWidth() &&
				y >= 0 && y < getHeight();
	}

	/**
	 * Validates if the given (x, y) is a valid pixel position,
	 * throwing an exception in case if it is not.
	 */
	void validatePosition(int x, int y) {
		if(!validPosition(x, y))
			throw new IllegalArgumentException(
					"invalid point " + x + ", " + y + 
					": matrix dimension is " + getWidth() + " x " + getHeight());
	}
}