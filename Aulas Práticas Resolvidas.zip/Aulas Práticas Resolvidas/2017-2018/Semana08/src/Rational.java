class Rational {
	final int numerador;
	final int denominador;
	
	Rational (int numerador){
		this.numerador=numerador;
		denominador=1;
	}
	
	Rational (int numerador, int denominador){
		if(denominador==0)
			throw new IllegalArgumentException("Denominador n�o pode ser igual a 0!");
		this.numerador=numerador;
		this.denominador=denominador;

	}
	
	int getNum(){
		return this.numerador;
	}
	int getDen(){
		return this.denominador;
	}
	
	double decimal (){
		return((double)getNum()/getDen());
	}
	
	static int mdc (int a, int b){
		if(b==0)
			return a;
		return mdc(b,a%b);
	}
	
	static int mmc(int a,int b){
		return a/mdc(a,b)*b;
	}
	private int novoNumerador(int novoDenominador){
		return novoDenominador/denominador*numerador;
	}
		
	
	Rational sum(Rational r){
		if(getDen()==r.getDen())
			return new Rational(getNum()+r.getNum(), getDen());
		else{
			int nDen= mmc(getDen(),r.getDen());
			int nNum= this.novoNumerador(nDen)+r.novoNumerador(nDen);
			return new Rational (nNum,nDen);
		}
	}
	
	Rational multiplica��oEsc (int n){
		return new Rational (numerador*n,denominador);
	}
	
	Rational multiplica��o (Rational r){
		return new Rational(getNum()*r.getNum(),getDen()*r.getDen());
	}
	
	boolean isEqualto(Rational r){
		return this.decimal()==r.decimal();
	}
	
	boolean �Maiorque(Rational r){
		return this.decimal()>r.decimal();
	}
	
	
	
	

}