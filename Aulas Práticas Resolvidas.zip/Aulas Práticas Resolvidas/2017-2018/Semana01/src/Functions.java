class Functions {
	
	static int square(int x) {
		return x*x;
	}
	
	static int dobro(int x){
		return 2*x;
	}
	
	static int diferen�a(int n1, int n2){
		return n1-n2;
	}
	
	static double percentagem(int n, int total){
		return (double)n/total; 
		
		// colocamos o (double) antes do n para transformar o inteiro
		//n em decimal. Como o c�culo � feito da esquerda para direita,
		//ent�o, a divis�o ser� decimal, em vez de inteira.
	}
	
	static double m�dia(int n3, int n4){
		return (double)(n3+n4)/2;
	}
	
	static int arredondar(double z){
		return (int)(z+0.5);
	}
	
	static boolean �Negativo(int n){
		return n<0;
	}
	
	static boolean impar(int n){
		return n%2!=0;
	}
	
	static boolean par(int n){
		return n%2==0;
	}
	
	static boolean par2(int n){
		return !impar(n);
	}
	
	static boolean m�ltiplo(int n, int n2){
		return n%n2==0;
	}
	
	static boolean intervalo(int n1){
		return n1>=0 && n1<=9;
	}
		
	static boolean intervaloF(int x1, int x2, int x3){
		return  x1>=x2 && x1<=x3;
	}
	
	static boolean exclu�do(int x1, int x2, int x3){
		return  x1<x2 || x1>x3;
	}
	
	static boolean exclu�do2(int x1, int x2, int x3){
		return  !intervaloF(x1,x2,x3);
	}
	
	static boolean XOR(boolean n, boolean m){
	return (n^m);
	}
	
	static boolean XOR1(boolean n, boolean m){
		return ((n||m)&&!(n&&m));
		}
	
	static boolean vogal (char n){
		return n=='a' || n=='e' || n=='i'||  n=='o' || n=='u';
	}
	
	//se eu quisesse descobrir se uma letra est� inclu�da em um intervalo de letras
	//por exemplo, saber se 'c' est� entre 'd' e 'j', posso usar os operadores
	//exemplo c>='d' && c<='j';
	
}