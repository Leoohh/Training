	
public class Program {

    public static void main(String[] a) {
        for(int i = 33; i != 128; i++)
            System.out.print(i + ": " + (char)i + "  ");
        System.out.println("END");
    }

}