package colors;

public class IntSet {

	private int[] vector;
	private int next;

	public IntSet (int tamanho){
		vector= new int[tamanho];
		//for(int i=0;i<tamanho;i++)
		//	vector[i]=(null);
		next=0;
	}


	public IntSet (int[] vector){
		this.vector=vector;
		next=vector.length;
	}

	public int capacidade (){
		return vector.length;
	}

	public int cardinalidade(){
		return next;
	}

	public boolean �Vazio (){
		return next==0;
	}

	public boolean est�Cheio (){
		return next==vector.length;
	}

	public boolean existe (int n){
		for(int i=0; i<next; i++){
			if(vector[i]==n)
				return true;
		}
		return false;
	}

	public int[] getElements(){
		int[] elements =new int[next];
		for(int i=0; i<next; i++)
			elements[i]=vector[i];
		return elements;
	}

	public void add (int n){
		if(existe(n)){
			System.out.println("O n�mero "+ n + " j� existe!");
			return;
		}
		if(next==vector.length)
			throw new NullPointerException("Conjunto cheio!");
		vector[next]=n;
		next++;
	}

	public void remover (int n){
		if(!existe(n)){
			System.out.println("O n�mero "+ n + " n�o existe!");
			return;
		}
		for(int i=0; i<next; i++){
			if (vector[i]==n){
				for(int j=i+1; j<next; j++)
					vector[j-1]=vector[j];
				vector[next-1]=0;
				next--;
				return;
			}
		}
	}

	public void dobrar (){
		int[] v=new int[2*vector.length];
		for(int i=0; i<next; i++)
			v[i]=vector[i];
		vector=v;
	}

	public IntSet union (IntSet set){
		int[] v=new int[next+set.cardinalidade()-interse��o(set).cardinalidade()];
		for(int i=0; i<next; i++)
			v[i]=vector[i];
		for(int i=0,j=next; i<set.cardinalidade(); i++)
			if(!existe(set.vector[i])){
				v[j]=set.vector[i];
				j++;
			}
		return new IntSet (v);
	}

	public IntSet interse��o (IntSet set){
		int[] v=new int[0];
		int a=0;
		for(int i=0;i<set.vector.length;i++){
			if(existe(set.vector[i])){
				int[]v1=new int[v.length+1];
				for(int j=0;j<v.length;j++)
					v1[j]=v[j];
				v1[a]=set.vector[i];
				a++;
				v=v1;
			}
		}
		return new IntSet(v);
	}








}