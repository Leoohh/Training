package colors;

public class Greytone implements IColor{
	private int value;

	public int getR(){
		return value;
	}

	public int getG(){
		return value;
	}

	public int getB(){
		return value;
	}

	public Greytone (int value){
		if(value < 0 || value > 255)
			throw new IllegalArgumentException("N�mero entre 0 e 255!");
		this.value=value;
	}

	public void brilho (int n){
		value=Math.min(Math.max(0,value+n),255);
	}

public static int luminance(IColor color) {
		return (int)(color.getR()*0.21+color.getG()*0.72+color.getB()*0.07);	
	}

}