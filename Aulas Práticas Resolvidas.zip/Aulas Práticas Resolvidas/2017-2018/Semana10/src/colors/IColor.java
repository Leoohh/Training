package colors;

public interface IColor {

	/**
	 * Devolve o valor de vermelho (Red) [0, 255]
	 */
	int getR();

	/**
	 * Devolve o valor de verde (Green) [0, 255]
	 */
	int getG();

	/**
	 * Devolve o valor de azul (Blue) [0, 255]
	 */
	int getB();

}