import colors.Greytone;
import colors.IColor;
import colors.IntSet;



class teste {
	
	static void teste3 (){
		IntSet z=new IntSet(5);
		int[]a={1,2,3,4,5};
		int[]b={1,3,5,7,9};
		IntSet v= new IntSet(a);
		IntSet w= new IntSet(b);
		IntSet y=v.interse��o(w);
		IntSet o=v.union(w);
		w.getElements();
		
	}
		

	static void teste (int value){
		Greytone rgb= new Greytone(value);
		rgb.brilho(70);
		int a=Greytone.luminance(rgb);
		Color c=new Color(40,23,21);
		int b=Greytone.luminance(c);



	}

	static void teste2 (int value, int width, int height, int w1,int h1){
		Rectangle r=new Rectangle (w1,h1);
		ColorImage img= new ColorImage (width, height);
		Greytone rgb= new Greytone(value);
		for (int i=0; i<w1&i<width; i++){
			for(int j=0;j<height&j<h1;j++)
				img.setColor(i,j,rgb);
		}
		return;
	}



}