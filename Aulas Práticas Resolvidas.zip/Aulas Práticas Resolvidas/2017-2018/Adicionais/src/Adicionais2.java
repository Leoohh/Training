class Adicionais2 {
	//Base
	static boolean �Min�scula (char c){
		return (c>96 && c<123);
	}
	//A
	static char complemento(char c){
		if(�Min�scula(c))
			return (char)('z'+'a'-c);
		else return c;
	}

	//B
	static boolean complementoVetor (char[]v){
		for (int i=1; i<v.length; i++){
			if (v[i]==complemento (v[0]))
				return true;
		}
		return false;
	}

	static boolean testeB (){
		char[]v={'a','B','&','z','g'};
		return complementoVetor(v);
	}

	//C
	static boolean complementoVetorI (char[]v,int j){
		for (int i=0; i<v.length; i++){
			if (v[i]==complemento (v[j]))
				return true;
		}
		return false;
	}

	static boolean testeC (int j){
		char[]v={'a','B','&','z','2'};
		return complementoVetorI(v,j);
	}
	//D
	static boolean B2 (char[]v){
		return complementoVetorI(v,0);
	}
	static boolean testeD (){
		char[]v={'a','B','&','z','2'};
		return B2(v);
	}
	//E
	static boolean todos(char[]v){
		int a=0;
		for (int i=0; i<v.length; i++){
			if (complementoVetorI(v,i))
				a++;
		}
		return (a==v.length);
	}
	static boolean testeE (){
		char[]v={'a','b','&','z','2'};
		return todos(v);
	}
	//F1
	static char[] F1 (char[]v){
		char[]v1=new char[2*v.length];
		for (int i=0;i<v.length; i++){
			v1[i]=v[i];
			v1[i+v.length]=complemento(v[i]);
		}
		return v1;
	}
	static char[] testeF1 (){
		char[]v={'a','b','c','d'};
		return F1(v);
	}
	//F2
	static char[] F2 (char[]v){
		char[]v1=new char[2*v.length];
		for (int i=0;i<v.length; i++){
			v1[i]=v[i];
			v1[2*v.length-i-1]=complemento(v[i]);
		}
		return v1;
	}
	static char[] testeF2 (){
		char[]v={'a','b','c','d'};
		return F2(v);
	}	
	//F3
	static char[] F3 (char[]v){
		char[]v1=new char[2*v.length];
		for (int i=0, j=0; i<v1.length-1 && j<v.length; i=i+2,j++){
			v1[i]=v[j];
			v1[i+1]=complemento(v[j]);
		}
		return v1;
	}
	static char[] testeF3 (){
		char[]v={'a','b','c','d'};
		return F3(v);
	}

	//G
	static char[][] matriz (int l, int c){
		char[][]m=new char[l][c]; //@matrix
		for (int i=0; i<m.length;i++){
			for(int j=0; j<m[i].length; j++){
				m[i][j]=(char)(int)(97+Math.random()*(122-97+1));
			}
		}
		return m;
	}

	//H
	static char[][] matrizNova (char[][]m){
		char[][]m1=new char[2*m.length][m[0].length];//@matrix
		for (int i=0, k=0; i<m.length&&k<m1.length;i++,k=k+2){
			m1[k]=m[i];
		}
		for(int j=1; j<m1.length; j=j+2){
			for (int l=0; l<m1[j].length; l++){
				m1[j][l]=complemento(m1[j-1][l]);
			}
		}
		return m1;
	}
	static char[][] testeH (){
		char[][]v={{'a','B','c','$','g'},{'y','t','4','r','R'},{'T','y','a','b','c'}};
		return matrizNova(v);
	}
		
	//I
	static char[][] matrizNova1 (char[][]m){
		char[][]m1=new char[2*m.length][];//@matrix
		for (int i=0, k=0; i<m.length&&k<m1.length;i++,k=k+2){
			m1[k]=m[i];
		}
		for(int j=1; j<m1.length; j=j+2){
			m1[j]=new char[m1[j-1].length];
			for (int l=0; l<m1[j-1].length; l++){
				m1[j][l]=complemento(m1[j-1][l]);
			}
		}
		return m1;
	}
	static char[][] testeI (){
		char[][]v={{'a','B','c','$'},{'y','t','4','r','R'},{'a','b','c'}};
		return matrizNova1(v);
	}
	
	static char convert  (int val){
		if (val<10)
			return 'D';
		else if (val>=10 &&  val<=13)
			return 'C';
		else if (val>=14&&val<=16)
			return 'B';
		else return 'A';
	}
	
	static double media (int[]v, char c){
		int acum=0,cont=0;
		for (int i=0; i<v.length; i++){
			if (convert(v[i])==c){
				acum+=v[i];
				cont++;
			}
		}
		return ((double)acum/cont);
	}
	
	static double teste (char c){
		int[]v={13,10,10,12,14};
		return media(v,c);
	}
}