class Adicionais {

	//A
	static boolean �Min�scula (char c){
		return (c>96 && c<123);
	}

	//B
	static int quantasMin (char[] v){
		int cont=0;
		for (int i=0; i<v.length; i++){
			if (�Min�scula(v[i]))
				cont++;
		}
		return cont;
	}

	static int testeB (){
		char[]v={'a','B','&','$','g'};
		return quantasMin(v);
	}

	//C
	static char[] novoMin (char[]v){
		char[]v1=new char[quantasMin(v)];
		int j=0;
		for (int i=0; i<v.length; i++){
			if (�Min�scula(v[i])){
				v1[j]=v[i];
				j++;
			}
		}
		return v1;
	}

	static char[] testeC (){
		char[]v={'a','B','&','$','g'};
		return novoMin(v);
	}

	//D
	static int MinMatriz (char[][]m){
		int cont=0;
		for (int i=0; i<m.length; i++)
			cont+=quantasMin(m[i]);
		return cont;
	}

	static int testeD (){
		char[][]v={{'a','B','&','$','g'},{'y','t','4','r','R'},{'T','y'}};
		return MinMatriz(v);
	}

	//E
	static int quantasVezes (char[] v, char c){
		int cont=0;
		for (int i=0; i<v.length; i++){
			if (c==v[i])
				cont++;
		}
		return cont;
	}

	static int testeE (char c){
		char[]v={'a','B','g','$','g'};
		return quantasVezes(v,c);
	}

	//F
	static boolean repetido1 (char[] v){
		for (int i=0; i<v.length; i++){
			if (quantasVezes(v,v[i])!=1)
				return true;
		}
		return false;
	}

	static boolean testeF (){
		char[]v={'a','B','g','$','g'};
		return repetido1(v);
	}

	//G
	static char uppercase (char c){
		if (!�Min�scula(c))
			return c;
		return (char)(c-32);
	}
	//H
	static char[] vetMaius (char[]v){
		for (int i=0;i<v.length; i++)
			v[i]=uppercase(v[i]);
		return v;
	}
	static void testeH (){
		char[]v={'a','B','g','$','g'};
		vetMaius(v);
	}

	//I
	static void matriz (char[][]m){
		for (int i=0; i<m.length; i++)
			m[i]=vetMaius(m[i]);
		return;
	}
	static void testeI (){
		char[][]v={{'a','B','&','$','g'},{'y','t','4','r','R'},{'T','y'}};
		matriz(v);
		return;
	}

	//J
	static char[] vetorInd (char[]v, int i,int j){
		if (�Min�scula(v[i]) && �Min�scula(v[j])){
			if (v[i]>v[j]){
				char aux=v[i];
				v[i]=v[j];
				v[j]=aux;
			}
		}
		return v;
	}
	static void testeJ (int i, int j){
		char[]v={'a','B','y','$','g'};
		vetorInd(v,i,j);
	}	
	//L
	static char[] ordenar(char[]v){
		boolean swap=true;
		while (swap==true){
			swap=false;
			for (int i=1; i<v.length; i++){
				if (v[i]<v[i-1]){
					char aux=v[i];
					v[i]=v[i-1];
					v[i-1]=aux;
					swap=true;
				}
			}
		}
		return v;
	}
	static char[] testeL (){
		char[]v={'b','d','a','A','c'};
		return ordenar(v);
	}
	
	//K
	static char[] menor (char []v){
		int a=0;
		for (int i=0; i<v.length; i++){
			if (v[i]<v[0])
				a=i;
		}
		return vetorInd (v,0,a);
	}
	
	static char[] testeK (){
		char[]v={'a','d','b','e','c'};
		return menor(v);
	}
	
	 static int[] f(int[][] m) {
	        int[] v = new int[Math.min(m.length, m[0].length)];
	        for(int i = 0; i != v.length; i++) {
	            v[i] = m[i][i];
	        }
	        return v;
	    }
	 static int[] teste(){
	 int[][] m = { {5, 6}, {3, 4}, {1, 2} };
	 return f(m);
	 }

}