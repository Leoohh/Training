class ColorUtils {

	static final int MAX=255;
	
	
	public static boolean contains (Color[] colors, Color c){
		for (int i=0;i<colors.length; i++){
			if(colors[i].isEqualto(c))
				return true;
		}
		return false;
	}
}