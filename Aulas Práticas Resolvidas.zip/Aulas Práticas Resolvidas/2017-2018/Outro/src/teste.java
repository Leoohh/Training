class teste {
	
	public static void teste (){
		Calculator a=new Calculator();
		Calculator b=new Calculator();
		a.plus(5);
		b.plus(7);
		Rational r=new Rational (4,5);
	}
	
	
	static boolean[][] m (){
		boolean[][]m1=new boolean[100][200];
		for(int i=0; i<m1.length; i++)
			for(int j=0;j<m1[0].length;j++){
				if(Math.random()<0.5)
					m1[i][j]=false;
				else m1[i][j]= true;
			}
	return m1;
	}
	
	
	static BinaryImage matriz (boolean[][]m){
		BinaryImage img= new BinaryImage(m[0].length,m.length);
		for(int i=0;i<m[0].length;i++)
			for(int j=0;j<m.length;j++){
				if(m[j][i]==true)
					img.setBlack(i,j);
				else img.setWhite(i,j);
			}
		return img;
	}
	
	static void test (){
		boolean[][]m1=m();
		BinaryImage img=matriz(m1);
		boolean[][]m=mat(img);
		return;
	}
	
	static boolean[][]mat(BinaryImage img){
		boolean[][]m=new boolean[img.getHeight()][img.getWidth()];
		for(int h=0;h<img.getHeight();h++)
			for(int w=0;w<img.getWidth();w++){
				if(img.isBlack(w,h))
					m[h][w]=true;
				else m[h][w]=false;
			}
		return m;
	}
	
	
		
}
	
	