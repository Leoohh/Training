class teste1 {
	
	static void teste(){
		ColorImage c5=new ColorImage("C:/Users/perei/Google Drive/workspace/Outro/src/Color(1).png");
		//c5.paste(c5,20,60);
		return;
	}

}