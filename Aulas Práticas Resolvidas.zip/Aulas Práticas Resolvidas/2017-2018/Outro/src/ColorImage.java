/**
 * Represents color images.
 * Image data is represented as a matrix:
 * - the number of lines corresponds to the image height (data.length)
 * - the length of the lines corresponds to the image width (data[*].length)
 * - pixel color is encoded as integers (ARGB)
 */
class ColorImage {

	private int[][] data; // @colorimage

	ColorImage(String file) {
		this.data = ImageUtil.readColorImage(file);
	}

	ColorImage(int width, int height) {
		data = new int[height][width];
	}


	int getWidth() {
		return data[0].length;
	}

	int getHeight() {
		return data.length;
	}

	void setColor(int x, int y, Color c) {
		data[y][x] = ImageUtil.encodeRgb(c.getR(), c.getG(), c.getB());
	}

	Color getColor(int x, int y) {
		int[] rgb = ImageUtil.decodeRgb(data[y][x]);
		return new Color(rgb[0], rgb[1], rgb[2]);
	}


	public void invert (){
		for (int i=0; i<getWidth();i++)
			for(int j=0;j<getHeight();j++)
				setColor(i,j,getColor(i,j).inversa());
	}

	public void brilho (int value){
		for (int i=0; i<getWidth();i++)
			for(int j=0;j<getHeight();j++)
				setColor(i,j,getColor(i,j).brighter(value));
	}

	public void espelhar (){
		for (int i=0; i<getWidth()/2;i++)
			for(int j=0;j<getHeight();j++){
				Color aux=getColor(i,j);
				setColor(i,j,getColor(getWidth()-i-1,j));
				setColor(getWidth()-i-1,j,aux);
			}
	}

	public void paste (ColorImage img,int x,int y){
		for (int i=x,a=0; i<getWidth()&&a<img.getWidth();i++,a++)
			for(int j=y,b=0;j<getHeight()&&b<img.getHeight();j++,b++)
				setColor(i,j,img.getColor(a,b));
	}

	public ColorImage pretoEbranco(){
		ColorImage img=new ColorImage(getWidth(),getHeight());
		for (int i=0; i<getWidth();i++)
			for(int j=0;j<getHeight();j++){
				if(getColor(i,j).getLuminance()<128)
					img.setColor(i,j,Color.PRETO);
				else img.setColor(i,j,Color.BRANCO);
			}
		return img;
	}

	public ColorImage copy(){
		ColorImage img=new ColorImage(getWidth(),getHeight());
		for (int i=0; i<getWidth();i++)
			for(int j=0;j<getHeight();j++)
				img.setColor(i,j,getColor(i,j));
		return img;
	}
	
	public ColorImage selection (int startX,int startY,int endX,int endY){
		if(startX<0 || startY<0 || endX<startX || endY< startY || startX>getWidth()||startY>getHeight())
			throw new IllegalArgumentException ("Valores inv�lidos para a imagem");
		ColorImage img=new ColorImage(endX-startX,endY-startY);
		for (int i=startX,a=0; i<endX;i++,a++)
			for(int j=startY,b=0;j<endY;j++,b++)
				img.setColor(a,b,getColor(i,j));
		return img;
	}


}