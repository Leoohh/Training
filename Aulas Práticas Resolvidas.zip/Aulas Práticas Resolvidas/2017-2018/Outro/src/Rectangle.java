class Rectangle {

	final int width;
	final int height;
	
	public Rectangle (int width, int height){
		this.width=width;
		this.height=height;
	}
	
	public Rectangle (int side){
		this(side,side);
	}
	
	public int area (){
		return width*height;
	}
	
	public int perimetro(){
		return 2*width+2*height;
	}
	
	public double diagonal(){
		return Math.sqrt(width*width+height*height);
	}
	
	public boolean isSquare(){
		return width==height;
	}
	
	public int getWidth(){
		return width;}
	
	public int getHeight(){
		return height;}
	
	public Rectangle scale(int factor){
		if(factor==1)
			return this;
		return new Rectangle (factor*getWidth(),factor*getHeight());
	}
	
	public Rectangle sum (int width, int height){
		return new Rectangle (getWidth()+width,getHeight()+height);
	}
	
	public boolean isBigger (Rectangle r){
		return this.area()>r.area();}
	
	public static Rectangle max (Rectangle a,Rectangle b){
		if(a.area()>=b.area())
			return a;
		return b;
	}
		
	
	
	
	
}