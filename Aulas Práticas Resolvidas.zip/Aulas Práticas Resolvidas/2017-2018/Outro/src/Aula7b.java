class Aula7b {
	
	public static BinaryImage random (int x,int y){
		BinaryImage img= new BinaryImage (x,y);
		for (int i=0;i<x;i++)
			for(int j=0;j<y;j++)
				if(Math.random()<0.5)
					img.setWhite(i,j);
				return img;
	}
	
	public static void paintSquare (BinaryImage img,int x,int y,int side){
		for (int i=x;i<x+side;i++)
			for(int j=y;j<y+side;j++){
				img.setWhite(i,j);
				//img.setBlack(i,y);
				//img.setBlack(i,y+side);
				//img.setBlack(x,j);
				//img.setBlack(x+side,j);
			}
	}
	
	public static void teste (){
		BinaryImage img=chess(25);
		BinaryImage a=size(img,2);
		BinaryImage merge=merge1(img,a);
		return;
	}
	
	public static BinaryImage chess (int pixeis){
		BinaryImage img=new BinaryImage(8*pixeis,8*pixeis);
		for(int i=1;i<img.getWidth()-1;i=i+pixeis)
			for(int j=1;j<img.getHeight()-1;j=j+pixeis)
				if((i+j)%2==0)
				paintSquare (img,i,j,pixeis-2);
		return img;
	}
	
	public static void invert (BinaryImage img){
		for (int i=0;i<img.getWidth();i++)
			for(int j=0;j<img.getHeight();j++){
				if(img.isBlack(i,j))
					img.setWhite(i,j);
				else img.setBlack(i,j);
			}
		return;
	}	
	
	public static BinaryImage invert2 (BinaryImage img){
		BinaryImage img1=new BinaryImage (img.getWidth(),img.getHeight());
		for (int i=0;i<img1.getWidth();i++)
			for(int j=0;j<img1.getHeight();j++){
				if(img.isBlack(i,j))
					img1.setWhite(i,j);
				else img1.setBlack(i,j);
			}
		return img1;
	}
	
	public static BinaryImage size (BinaryImage img,int factor){
		BinaryImage img1= new BinaryImage (factor*img.getWidth(),factor*img.getHeight());
		for (int i=0; i<img1.getWidth();i++)
			for (int j=0;j<img1.getHeight();j++){
				if(img.isBlack(i/factor,j/factor))
					img1.setBlack(i,j);
				else img1.setWhite(i,j);
			}
		return img1;
	}
	/**
	public static BinaryImage merge (BinaryImage img1,BinaryImage img2){
		BinaryImage img=new BinaryImage(Math.max(img1.getWidth(),img2.getWidth()),Math.max(img1.getHeight(),img2.getHeight()));
		for(int i=0;i<Math.min(img1.getWidth(),img2.getWidth());i++)
			for(int j=0;j<Math.min(img1.getHeight(),img2.getHeight());j++){
				if(img1.isBlack(i,j)||img2.isBlack(i,j))
					img.setBlack(i,j);
				else if(!img1.isBlack(i,j)&&!img2.isBlack(i,j))
					img.setWhite(i,j);
			}
		return img;
	}
	**/
	public static BinaryImage merge1 (BinaryImage small, BinaryImage big){
		BinaryImage img= new BinaryImage(Math.max(big.getWidth(),small.getWidth()),Math.max(big.getHeight(),small.getHeight()));
		for (int i=0; i<img.getWidth();i++){
			for (int j=0; j<img.getHeight();j++){
				if ( i < small.getWidth() && j<small.getHeight() &&!small.isBlack(i,j))
					img.setWhite(i,j);
				else if ( i < small.getWidth() && j<small.getHeight() && small.isBlack(i,j))
					img.setBlack(i,j);
				else if ((i>small.getWidth()||j>small.getHeight())&&!big.isBlack(i,j))
					img.setWhite(i,j);
				else if ((i>small.getWidth()||j>small.getHeight())&&big.isBlack(i,j))
					img.setBlack(i,j);
			}
			
		}

		return img;
	}
	
	public static void circle (BinaryImage img, int raio,int x,int y){
		for (int i=x-raio;i<x+raio;i++)
			for (int j=y-raio;j<y+raio;j++)
				if(Math.sqrt((i-x)*(i-x)+(j-y)*(j-y))<raio)
					if(Math.random()>0.5)
						img.setWhite(i,j);
		
	}

	public static void testeB (){
		BinaryImage img=new BinaryImage (100,200);
		circle (img,20,50,100);
		return;
	}
}