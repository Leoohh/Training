class Aula7 {
	
	public static Color randomColor(){
		Color c= new Color((int)(Math.random()*256),(int)(Math.random()*256),(int)(Math.random()*256));
	return c;
	}

	public static Color[] arrayofRandomColors (int length){
		Color[] colors= new Color[length];
		for(int i=0;i<length;i++)
			colors[i]=randomColor();
	return colors;
	}
	
	public static Color inverted (Color c){
		Color invert= new Color(255-c.getR(),255-c.getG(),255-c.getB());
		return invert;
	}
	
	public static void teste (){
		Color c=new Color(155,155,155);
		Color a= luminosidade (c,200);
		return;
	}
	
	public static Color luminosidade (Color c,int factor){
		Color a= new Color (Math.min(255,c.getR()+factor),Math.min(255,c.getG()+factor),Math.min(255,c.getB()+factor));
		return a;
	}
	
}