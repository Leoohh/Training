public class Fibonacci {
	
	
	//1� M�todo
	public static int fibonacci (int x){
		if (x<2)
			return x;
		int a=0;
		int b=1;
		int cont=2;
		int aux=0;
		while (cont<=x){
			aux=a+b;
			a=b;
			b=aux;
			cont=cont+1;
		}
		return aux;
		}
	
	
	
	
	
	//2� M�todo - recursividade
	public static int fib (int n){
		if (n<2)
			return n;
		return fib(n-2)+fib(n-1);
	}
	
	static int primeiroDigito (int x){
		while (x>=10){
			x=x/10;
		}
		return x;
	}

}

