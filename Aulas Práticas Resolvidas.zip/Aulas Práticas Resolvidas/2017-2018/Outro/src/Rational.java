class Rational {
	
	final int den;
	final int num;
	
	public Rational (int num, int den){
		if(den==0)
			throw new IllegalArgumentException("Denominador n�o pode ser igual a 0!");
		this.den=den;
		this.num=num;
	}
	
	public Rational (int num){
		den=1;
		this.num=num;
	}
	
	public double real (){
		return (double)(num)/den;
	}
	
	private static int mdc (int a, int b){
		if(b==0)
			return a;
		return mdc(b,a%b);
	}
	
	private static int mmc(int a,int b){
		return a/mdc(a,b)*b;
	}
	private int novoNumerador(int novoDenominador){
		return novoDenominador/den*num;
	}
		
	
	public Rational sum(Rational r){
		if(den==r.den)
			return new Rational(num+r.num, den);
		else{
			int nDen= mmc(den,r.den);
			int nNum= this.novoNumerador(nDen)+r.novoNumerador(nDen);
			return new Rational (nNum,nDen);
		}
	}
	
	public Rational multiplicarEsc (int n){
		return new Rational (n*num,den);
	}
	
	public Rational multiplicar (Rational r){
		return new Rational (num*r.num,den*r.den);
	}
	
	public boolean isEqualto (Rational r){
		return num==r.num && den==r.den;
	}
	
	boolean �Maiorque(Rational r){
		return real()>r.real();
	}
		
}