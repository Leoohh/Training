class FirstDigit {
	
	//Problema: Como ensinar o computador a descobrir o primeiro d�gito de um n�mero?
	
	public static int divis�oPorDez (int numero){
		return numero/10;
	}
	
	public static int primeiroDigito (int x){
		while (x>=10){
			x=x/10;
		}
		return x;
	}

}