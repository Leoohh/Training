public class Calculator {
	
	int value;
	
	public void plus (int n){
		value+=n;
	}
	
	public void clean (){
		value=0;
	}
	
	public void subtra��o (int n){
		value-=n;
	}
	
	public void multiplica��o (int n){
		int aux=0;
		for (int i=1; i<=n; i++)
			aux+=value;
		value=aux;
	}
	
	public void potencia (int n){
		if (n==0){
			value=1;
			return;
		}
		int aux=value;
		for (int i=2; i<=n;i++)
			multiplica��o(aux);
	}
	
	public void divis�o (int n){
		int resto=value;
		int quociente = 0;
		while (resto>=n){
			resto=resto-n;
			quociente++;
		}
		value=quociente;
	}
	
	public void resto (int n){
		int resto=value;
		while (resto>=n){
			resto=resto-n;
		}
		value=resto;
	}
}