class ColorUtils {
	
	static final int MAX=255;
	
	static boolean contains (Color[]colors, Color c){
		for(int i=0; i<colors.length; i++){
			if(c.�Igual(colors[i]))
					return true;
		}
		return false;
	}
	
	static Color[] randomcolors(int n){
		Color[]vc=new Color[n];
		for (int i=0; i<n; i++)
			vc[i]=new Color((int)(Math.random()*256),(int)(Math.random()*256),(int)(Math.random()*256));
		return vc;
	}
	
		

}