class Images {

	public static void posterize (ColorImage img,Color dark, Color light){
		for (int i=0; i<img.getWidth();i++)
			for(int j=0;j<img.getHeight();j++){
				if(img.getColor(i,j).getLuminance()<128)
					img.setColor(i,j,dark);
				else img.setColor(i,j,light);
			}
	}
	/*
	public static ColorImage popArt (ColorImage img){
		ColorImage pop=new ColorImage (2*img.getWidth(),2*img.getHeight());
		pop.paste(posterize(img,
	 */


	public static ColorImage[] vetor(ColorImage img){
		ColorImage[]v=new ColorImage[4];
		v[0]=img.selection(0,0,img.getWidth()/2,img.getHeight()/2);
		v[1]=img.selection(img.getWidth()/2,0,img.getWidth(),img.getHeight()/2);
		v[2]=img.selection(0,img.getHeight()/2,img.getWidth()/2,img.getHeight());
		v[3]=img.selection(img.getWidth()/2,img.getHeight()/2,img.getWidth(),img.getHeight());
		return v;
	}


		public static ColorImage merge(ColorImage img1,ColorImage img2){
			ColorImage img=new ColorImage(img1.getWidth()+img2.getWidth(),img1.getHeight());
			for (int i=0; i<img1.getWidth();i++)
				for(int j=0;j<img1.getHeight();j++)
					img.setColor(i,j,img1.getColor(i,j));
			for (int i=0,a=img1.getWidth(); i<img2.getWidth();i++,a++)
				for(int j=0,b=0;j<img2.getHeight();j++,b++)
					img.setColor(a,b,img2.getColor(i,j));
			return img;
		}
	}