class teste {
	
	static void teste(){
		/*
		Color c1=Color.BLACK;
		Color c2=c1.inversa();
		Color c4=new Color(0,0,0);
		Color c3=c2.brighter(-40);
		boolean b= c1.�Igual(c3);
		
		Color[]vc=ColorUtils.randomcolors(5);
		boolean b2=ColorUtils.contains(vc,c1);
		*/
		Color[] v = new Color[3];
		int i = 1;
		while(i != v.length) {
		    v[i] = Color.RED;
		    i = i + 1;
		}
		ColorImage c5=new ColorImage("C:/Users/perei/Google Drive/workspace/Aula9/src/objc1.png");
		mirror(c5);
		ColorImage c6= c5.copy();
		c5.espelho();
		//ColorImage c7=c5.pretoebranco();
		//c5.brilho(40);
		c5.invert();
		ColorImage k=Images.merge(c5,c6);
		
		ColorImage img= c5.selection(40,50,150,200);
		
		c5.paste(40,70,img);
		
		ColorImage[]v1=Images.vetor(c6);
		
		//Images.posterize(c6,Color.BLUE,Color.WHITE);
		 
		//ColorImage d=Images.popArt(c6);
		
		
	}
	 static void mirror(ColorImage img) {
	        for(int x = 0; x != img.getWidth(); x++) {
	            for(int y = 0; y != img.getHeight()/2; y++) {
	                Color color = img.getColor(x, y);
	                img.setColor(x, y, img.getColor(x, img.getHeight() - 1 - y));
	                img.setColor(x, img.getHeight() - 1 - y, color);
	            }
	        }
	    }
		
		

}