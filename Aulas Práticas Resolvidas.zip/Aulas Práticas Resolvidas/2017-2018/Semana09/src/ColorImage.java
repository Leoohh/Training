/**
 * Represents color images.
 * Image data is represented as a matrix:
 * - the number of lines corresponds to the image height (data.length)
 * - the length of the lines corresponds to the image width (data[*].length)
 * - pixel color is encoded as integers (ARGB)
 */
class ColorImage {

	private int[][] data; // @colorimage

	ColorImage(String file) {
		this.data = ImageUtil.readColorImage(file);
	}

	ColorImage(int width, int height) {
		data = new int[height][width];
	}

	int getWidth() {
		return data[0].length;
	}

	int getHeight() {
		return data.length;
	}

	void setColor(int x, int y, Color c) {
		data[y][x] = ImageUtil.encodeRgb(c.getR(), c.getG(), c.getB());
	}

	Color getColor(int x, int y) {
		int[] rgb = ImageUtil.decodeRgb(data[y][x]);
		return new Color(rgb[0], rgb[1], rgb[2]);
	}
	
	//EXTRAS AULA 09
	
	void invert(){
		for(int w=0;w<getWidth(); w++){
			for(int h=0; h<getHeight(); h++)
				setColor(w,h,getColor(w,h).inversa());
		}
	}
	
	
	
	void espelho (){
		for(int w=0;w<getWidth()/2; w++){
			for(int h=0; h<getHeight(); h++){
				Color aux= getColor(getWidth()-w-1,h);
				setColor(getWidth()-w-1,h,getColor(w,h));
				setColor(w,h,aux);
			}
				
		}
	}
	
	//7
	ColorImage selection (int starX, int starY,int endX, int endY){
		ColorImage img= new ColorImage(endX-starX,endY-starY);
		for(int w=starX,a=0;w<endX&&a<img.getWidth(); w++,a++){
			for(int h=starY,b=0; h<endY&&b<img.getHeight(); h++,b++)
				img.setColor(a,b,this.getColor(w,h));
		}
	return img;
	}
	
	//4
	void paste1(int x,int y, ColorImage img){
		for(int w=x,a=0;w<x+img.getWidth()&&a<img.getWidth(); w++,a++){
			for(int h=y,b=0; h<y+img.getHeight()&&b<img.getHeight(); h++,b++)
				setColor(w,h,img.getColor(a,b));
		}
	}
	void paste(int x,int y, ColorImage img){
		for(int w=x,a=0;w<x+this.getWidth()&&a<img.getWidth(); w++,a++){
			for(int h=y,b=0; h<y+this.getHeight()&&b<img.getHeight(); h++,b++)
				setColor(w,h,img.getColor(a,b));
		}
	}
	
	ColorImage pretoebranco (){
		ColorImage img=new ColorImage(getWidth(),getHeight());
		for(int w=0;w<getWidth(); w++){
			for(int h=0; h<getHeight(); h++){
				if(getColor(w,h).getLuminance()<128){
					img.setColor(w,h,Color.BLACK);
				}
				else{
					img.setColor(w,h,Color.WHITE);
				}
			}
		}
		return img;
	}
	
	ColorImage copy(){
		ColorImage img=new ColorImage(getWidth(),getHeight());
		for(int w=0;w<getWidth(); w++){
			for(int h=0; h<getHeight(); h++)
				img.setColor(w,h,getColor(w,h));
		}
		return img;
	}
	
	
				
		
}