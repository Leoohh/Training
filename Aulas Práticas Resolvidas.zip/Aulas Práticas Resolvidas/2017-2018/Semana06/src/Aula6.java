class Aula6 {
	//a
	static int[][]randomMatrix(int lines, int colunas){
		int[][]m= new int[lines][colunas]; //@matrix
		for (int i=0; i<m.length; i++){
			for (int j=0; j<m[i].length; j++){
				m[i][j]=(int)(Math.random() * 10);
			}
		}
		return m;  
	}
	//b

	static int[][]randomMatrixQuadrada(int n){
		return randomMatrix(n,n);  //@matrix
	}

	//c
	static int somat�rio(int[][]m){
		int sum=0;
		for (int i=0; i<m.length; i++){
			for(int j=0;j<m[i].length; j++){
				sum += m[i][j];
			}
		}
		return sum;
	}

	static int testeb(){
		int [][]m={{-1,5,7,8},{-3},{1,1,1,}}; //@matrix
		return somat�rio(m);
	}
	//c
	static int numerodeElementos(int[][]m){
		int n=0;
		for (int i=0; i<m.length; i++){
			for (int j=0; j<m[i].length; j++, n++){
			}
		}
		return n;  
	}

	static int testec(){
		int [][]m={{-1,5,7,8},{-3},{1,1,1,}}; //@matrix
		return numerodeElementos(m);
	}
	//A

	static int[] todosElementos(int[][]m){
		int[]v=new int[numerodeElementos(m)];
		for (int i=0, index=0; i<m.length; i++){
			for(int j=0;j<m[i].length; j++, index++){
				v[index]=m[i][j];
			}
		}
		return v;
	}

	static int[] testeA(){
		int [][]m={{-1,5,7,8},{-3},{1,1,1,}}; //@matrix
		return todosElementos(m);
	}	

	//B
	static int[][] matrizVetor (int[]v, int l, int c){
		int [][]m=new int[l][c]; //@matrix
		for (int i=0, index=0;i<m.length; i++){
			for(int j=0;j<m[i].length; j++, index++){
				m[i][j]=v[index];
			}
		}
		return m;
	}

	static int[][] testeB(int l, int c){
		int[]v={1,2,3,4,5,6,7,8,9,10};
		return matrizVetor(v,l,c);
	}

	//C
	static boolean MatrizAlg (int[][]m){
		int p=m[0].length;
		for (int i=1; i<m.length; i++){
			if(m[i].length!=p)
				return false;
		}
		return true;
	}
	static boolean testeC(){
		int [][]m={{-1,5,7,8},{-3,3,2,1},{1,1,1,4}}; //@matrix
		return MatrizAlg(m);
	}

	//D
	static boolean MatrizQuaAlg(int[][]m){		
		return (MatrizAlg(m)&&m.length==m[0].length);
	}

	static boolean testeD(){
		int [][]m={{-1,5,7,8},{-3,2,1},{1,1,1,4},{6,4,3,5}}; //@matrix
		return MatrizQuaAlg(m);
	}

	//E
	static boolean MatrizIgual (int[][]m,int[][]n){
		if (m.length!=n.length)
			return false;
		//	if(numerodeElementos(m)!=numerodeElementos(n))
		//		return false;
		for (int i=0; i<m.length; i++){
			if(m[i].length!=n[i].length)
				return false;
			for (int j=0; j<m[i].length; j++){
				if(m[i][j]!=n[i][j])
					return false;
			}
		}
		return true;
	}


	static boolean testeE(){
		int [][]m={{-1,5,7,8},{-3,3,2,1},{1,1,1,4},{6,4,3,5}}; //@matrix
		int[][]n={{-1,5,7,8},{-3,3,2,1},{1,1,1},{6,4,3,5,5}};
		return MatrizIgual(m,n);
	}


	///////
	//F

	static int[][]identidade(int n){
		int[][]m=new int[n][n]; //@matrix
		for (int i=0; i<m.length; i++)
			m[i][i]=1;
		return m;
	}

	//G
	static int[][]multiplicarEsc(int[][]m,int x){
		for (int i=0; i<m.length; i++){
			for (int j=0; j<m[i].length; j++){
				m[i][j]*=x;
			}
		}
		return m;
	}

	static int[][] testeG(int escalar){
		int [][]m={{2,2,2,3},{1,2,2,2},{1,1,1,4},{6,4,3,5}}; //@matrix
		return multiplicarEsc(m, escalar);
	}

	//H
	static int[][] somaMatriz (int[][]m, int[][]n){
		for (int i=0; i<m.length; i++){
			for (int j=0; j<m[i].length; j++){
				m[i][j]+=n[i][j];
			}
		}
		return m;
	}
	static int[][] testeH(){
		int[][]m={{-1,5,7,8},{-3,3,2,1},{1,1,1,4},{6,4,3,5}}; //@matrix
		int[][]n={{-1,5,7,8},{-3,3,2,1},{1,3,1,1},{6,4,3,5}};
		return somaMatriz(m,n);
	}

	//I

	static boolean �Identidade(int[][]m){
		if(!MatrizQuaAlg(m))
			return false;
		if(somat�rio(m)!=m.length)
			return false;
		for (int i=0; i<m.length; i++){
			if (m[i][i]!=1)
				return false;
		}
		return true;
	}
	static boolean testeI(){
		int [][]m={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}}; //@matrix
		return �Identidade(m);
	}
	
	//J
	
	static int[] coluna(int[][]m,int c){
		if(c>m[0].length||c<=0)
			return null;
		int[]v=new int[m.length];
		for (int i=0, index=0; i<m.length;i++, index++)
			v[index]=m[i][c-1];
		return v;
	}
	
	static int[] testeJ(int c){
		int[][]m={{-1,5,7,8},{-3,3,2,1},{1,3,1,1},{6,4,3,5}};
		return coluna(m,c);
	}
	
	//K
	static int[][]Transposta(int[][]m){
		int[][]n= new int[m[0].length][m.length]; //@matrix
		for (int i=0; i<m.length; i++){
			for (int j=0; j<m[i].length; j++){
				n[j][i]=m[i][j];
			}
		}
		return n;  
	}
	static int[][] testeK(){
		int[][]m={{1,2,3,4},{3,3,4,5},{4,4,5,6},{5,5,6,7}};
		return Transposta(m);
	}
	
	//L -confirmar
	
	static boolean �Sim�trica(int[][]m){
		return MatrizIgual(m,Transposta(m));
	}
	
	static boolean testeL(){
		int[][]m={{1,1},{1,1}}; //@matrix
		return �Sim�trica(m);
	}


	//extra

	static int[][] multiplica��oMatrix(int[][]m,int[][]n){
		int[][] p=new int[m.length][n[0].length]; //@matrix
		for (int i=0; i<m.length; i++){ //linhas de m
			for (int k=0; k<n[0].length; k++){ //colunas de n
				for (int l=0, j=0; l<m[i].length&&j<n.length;l++,j++) //elementos da linha de m
					//for (int j=0; j<n.length; j++){ //elementos da coluna de n
					p[i][k]+=m[i][l]*n[j][k];
			}
		}
		return p;
	}

	static int[][] testeExtra(){
		int[][]m= {{1,2},{2,1},{3,3}};//@matrix
		int[][]n={{1,2,2},{2,1,2}}; //@matrix
		return multiplica��oMatrix(m,n);
	}


}