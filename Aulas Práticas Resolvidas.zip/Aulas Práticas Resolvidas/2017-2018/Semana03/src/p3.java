class p3 {
	
	static boolean �Divisor (int n, int i){	
		return n%i==0;
	}
	
	static int numerodeDivisores (int n){
		int i=1;
		int numero=0;
		while (i<=n){
			if (n%i==0)
				numero++;
			i++;
		}
		return numero;
	}		
	
	static int numerodeDivisores2 (int n){
		int i=1;
		int numero=0;
		while (i<=n){
			if (�Divisor (n,i))
				numero=numero+1;
			i++;
		}
		return numero;
	}	

	static int somadedivisores (int n){
		int i=1;
		int soma=0;
		while (i<n){
			if (n%i==0)
				soma=soma+i;
			i++;
		}
		return soma;
	}		
	
	static int somadedivisores1 (int n){
		int i=1;
		int soma=0;
		while (i<n){
			if (�Divisor (n,i))
				soma=soma+i;
			i++;
		}
		return soma;
	}	
	
	static boolean isPrime (int n){
			return (numerodeDivisores(n)==2);
	}
	
	static int sumofPrimes (int n){
		int i=1;
		int soma=0;
		while (i<n){
			if (isPrime (i))
				soma=soma+i;
			i=i+1;
		}
		return soma;
	}
	
	static int sumOfPri (int n){
		if (n<2)
			return 0;
		else
			if (isPrime (n-1))
				return ((n-1)+ sumOfPri(n-1));
			else return sumOfPri (n-1);
	}
	
			
	static int numerodePrimos (int n){
		int i=1;
		int acum=0;
		while (i<=n){
			if (isPrime (i))
				acum=acum+1;
			i=i+1;
		}
		return acum;
	}
	
	static boolean �Perfeito(int n){
		return somadedivisores(n)==n;
	}
	
	static int numerosPerfeitos (int n){
		int i=1;
		int acum=0;
		while (i<=n){
			if (�Perfeito(i))
				acum++;
			i=i+1;
		}
		return acum;
	}
	
	static boolean primosnoIntervalo (int n, int m){
		int aux=0;
		if (m<n){
			aux=n;
			n=m;
			m=aux;;
		}
		int i=n+1;
		while (i<m){
			if(isPrime(i))
				return true;
				else i++;
		}
		return false;
	}
			
	static int fat (int n){
		if (n==0)
			return 1;
		return n*fat(n-1);
	}
	
	static int fib (int n){
		if (n<2)
			return n;
		return fib(n-2)+fib(n-1);
	}
	
	static int mdc (int n, int m){
		if (m==0)
			return n;
		return mdc (m, n%m);
	}
	
	//extra
	
	static int maxDif (int n){
		int primo1=2;
		int maiorDif=0;
		int i=0;
		while (i<=n){
			if (isPrime (i)){
				if (i-primo1 > maiorDif)
				maiorDif=i-primo1;
				primo1=i;
			}
			i++;
		}
		return maiorDif;
	}
	
}