class p2 {
	static int max (int a, int b){
		if (a>b)
			return a;
		return b;
	}

	static boolean �multiplo (int m, int n){
		int resto= m;
		int quociente = 0;
		while (resto>=n){
			resto=resto - n;
			quociente = quociente + 1;
		}
		return resto == 0;
		
	}
	
	static int abs (int x){
		if (x>0)
			return x;
		return -x;
	}

	static int divis�o (int m, int n){
		int resto= m;
		int quociente = 0;
		while (resto>=n){
			resto=resto - n;
			quociente = quociente + 1;
		}
		return quociente;
	}
	
	static int pot�nciaDe2 (int x){
		int res=1;
		int acum = x;
		if (x>0){
			while (acum > 0){
				res=res*2;
				acum=acum-1;
			}
		}
		return res;
	}
// ou
		
		static int pot (int w){
			int acum1=2;
			int cont1=1;
			while (cont1!=w){
				acum1=acum1*2;
				cont1=cont1+1;
			}
			return acum1;
		}

	static int somatorio (int n){
		int soma=0;
		int cont=0;
		if (n>=0)
		while (cont<=n){
			soma=soma+cont;
			cont=cont+1;
		}
		return soma;
	}

	static int somapar (int n, int m){
		int soma=0;
		int cont=n;
		while (cont<=m){
			if (cont%2==0)
				soma=soma+cont;
			cont=cont+1;
		
		}
		return soma;
	}
	
	static int primeiroDigito (int x){
		while (x>=10){
			x=x/10;
		}
		return x;
	}
	
	static int fibonnaci (int x){
			if (x<2)
				return x;
			int a=0;
			int b=1;
			int cont=2;
			int aux=0;
			while (cont<=x){
				aux=a+b;
				a=b;
				b=aux;
				cont=cont+1;
			}
			return aux;
			}
			
	
	static int mdc (int m, int n){
		int resto=0;
		while (n!=0){
			resto=m%n;
			m=n;
			n=resto;
		}
		return m;
	}		
	//ou
	static int mdc2 (int a, int b){
		int M=a;
		int m=b;
		if (b>a){
			M=b;
			m=a;
		}
		while (m!=0){
			M=M-m;
			if (m>M){
				int t=M;
				M=m;
				m=t;
			}
		}
		return M;
	}

}
