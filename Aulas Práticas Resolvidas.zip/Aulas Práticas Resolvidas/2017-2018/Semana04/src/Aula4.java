class Aula4 {
	static int[] naturals(int n){
		int[] v = new int[n];
		int i=0;
		while (i<n){
			v[i]=i+1;
			i++;
		}
		return v;
	}
	
	static int soma (int [] v){
		int i=0;
		int acum=0;
		while (i < v.length){
			acum+=v[i]; // acum=acum+v[i]
			i++;
		}
		return acum;
	}
	
	static int teste(){
		int [] v=naturals(5);
		return soma(v);
	}
	
	static int[] aleatorio(int n){
		int[] v=new int[n];
		int i=0;
		while (i<n){
			v[i]=(int)(Math.random()*10);
			i++;
		}
		return v;
		}
	
	static double media (int[]v){
		return (soma(v)/(double)v.length);
	}
	static double testeA(){
		int v[]=naturals(2);
		return media(v);
	}
	// ou
	
	static double media(int n){
		int[] v=naturals(n);
		return soma(v)/(double)v.length;
	}
			
	static int[] replica (int v1[], int n){
		int i=0;
		int[]v2=new int[n];
		while (i<v1.length && i<v2.length){
			v2[i]=v1[i];
			i++;
		}
			return v2;
		}
	
	static int[] testeB(int tam1, int tam2 ){
		int v[]=naturals(tam1);
		return replica(v, tam2);
	}
	
	static int[] replicaIgual (int v[]){
		return replica (v, v.length);
	}
	
	static int[] testeC(int tam1){
		int v[]=naturals(tam1);
		return replicaIgual(v);
	}
	
	static boolean existe(int n){
		int v1[]=naturals(5);
		int i=0;
		while (i<v1.length){
			if (v1[i]==n)
				return true;
			i++;
		}
		return false;
	}

	static int quantasVezes(int n){
		int[]v={3,4,6,3,1,10,5,3};
		int i=0;
		int cont=0;
		while (i<v.length){
			if (v[i]==n)
				cont++;
			i++;
		}
		return cont;
	}
		static int m�ximo(){
			int []v={3,1,7,8,10,1};
			int i=0;
			int max=v[0];
			while (i<v.length){
				if (max<v[i])
					max=v[i];
				i++;
			}
			return max;
		}
		
		static int[] subVetor (int a, int b, int[]v){
			if (b<a)
				return null;
			int []v1=new int[b-a+1];
			int i=a;
			while (i<b+1){
				v1[i-a]=v[i];
				i++;
			}
			return v1;
		}
		
		static int[] testeG (){
			int []v=aleatorio(8);
			return subVetor(2,4, v);
		}
			
		static int[] metade (int[]v, boolean x){
			int b;
			if (v.length%2==0 || !x)
				b=v.length/2-1;
			else
				b=v.length/2;	
			return subVetor (0,b,v);
		}
			
		static int[] testeH(){
			int[]v={1,2,5,7,88,7,2};
			return metade(v, true);
		}
			
		static int[] metade2 (int[]v, boolean x){
			int b;
			if (v.length%2==0 || x)
				b=v.length/2;
			else
				b=v.length/2+1;
			int a=v.length-1;
			return subVetor (b,a,v);
		}
		
		static int[] testeI(){
			int[]v={1,2,5,7,88,7,2,8};
			return metade2(v, false);
		}
		
		static int[] DoisVetores(int[]v1, int[]v2){
			int []v=replica(v1, v1.length+v2.length);
			int i=v1.length;
			while (i<v.length){
				v[i]=v2[i-v1.length];
				i++;
			}
		
			return v;
		}
		
		static int[] testeJ (){
			int []v1={1,2};
			int []v2={5,8};
			return DoisVetores(v1,v2);
		}
				
		static int[] vetorInvertido (int[]v1){
			int i=0;
			int[]v=new int[v1.length];
			while (i<v1.length){
				v[i]=v1[v.length-1-i];
				i++;
			}
			return v;
		}
		
		static int[] testeK (){
			int []v1={1,2,3};
			return vetorInvertido(v1);
		}
		
		static int sorteio(int []v){
			return v[(int)(Math.random()*10)];
		}
			
		static int testeL(){
			int []v=naturals(10);
			return sorteio(v);
		}
		
		static int[] vetorDup (int v[]){
			int[]vNew=new int[2*v.length];
			int i=0;
			vNew[0]=v[0];
			while (i<v.length){
				vNew[2*i]=v[i];
				vNew[2*i+1]=v[i];
				i++;
			}
			return vNew;
		}
		
		static int[] testeAex (){
			int[] v=naturals(5);
			return vetorDup(v);
		}
		
		static int[] ExerB (int v[]){
			int[] vNew=new int [v.length*2];
			int i=0;
			int j=vNew.length-1;
			while (i<v.length){
				vNew[i]=v[i];
				i++;
			}
			while (j>=v.length){
				vNew[j]=v[vNew.length-j-1];
				j=j-1;
			}
			return vNew;
		}
		
		static int[] testeBex(){
			int []v={3,2,1};
			return ExerB(v);
		}
		
		static int[] copyWithoutMid ( int[] v ) {

			int t = v.length;
			if ( v.length %2 == 1 )
				t = t - 1;
			int[] novo = new int [t];

			int i = 0;
			while ( i < novo.length ) {
			if ( i < v.length / 2 )
			novo[i] = v[i];
			else if ( v.length %2 == 1 )
			novo[i] = v[i+1];
			i = i + 1;
			}
			return novo;
			}
		
		static int[] testeExC(){
			int[]v={1,2,3,4,5};
			return copyWithoutMid(v);
		}
		
		static int[] fibonnaciVetor(int n){
			int i=2;
			int[]v=new int[n];
			if (n==0) return v;
			if (n==1){
				v[1]=1;
				return v;
			}
			else{
				v[1]=1;
				while (i<n){
					v[i]=v[i-2]+v[i-1];
					i++;
				}
			}
			return v;
		}
			
}	



